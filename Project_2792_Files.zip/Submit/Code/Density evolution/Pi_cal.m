function [ProbVec] = Pi_cal(inputSets,sumLook)




end

