Project Files  ----- No. 2792 
LDPC codes and q-ary bit measurment channel
Noam Shilony --------- noamsh@campus.technion.ac.il
Dore Kleinstern 